/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.cache.projectors.sinks.builder;

import io.telicent.smart.cache.projectors.Sink;

/**
 * Interface for sink builders
 *
 * @param <TItem> Item type
 * @param <TSink> Built sink type
 */
// java:S119 - TKey/TValue/TRequest generic naming convention is used across the codebase
@SuppressWarnings("java:S119")
public interface SinkBuilder<TItem, TSink extends Sink<TItem>> {

    /**
     * Builds the Sink
     *
     * @return Sink
     */
    TSink build();
}
