/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.cache.observability;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.Meter;
import io.telicent.smart.cache.configuration.Configurator;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Entrypoint for Telicent related metrics
 */
public class TelicentMetrics {
    /**
     * Standard OpenTelemetry system property for the service instance ID, e.g. {@code -Dotel.service.instance.id=...}
     */
    private static final String OTEL_INSTANCE_ID_PROPERTY = "otel.service.instance.id";
    private static final String INSTANCE_ID_ENV = "OTEL_SERVICE_INSTANCE_ID";
    private static final String HOSTNAME_ENV = "HOSTNAME";
    private static final String SHARED_INSTANCE_ID_PROPERTY = "telicent.metrics.instance.id";

    private static OpenTelemetry OTEL = null;
    private static String INSTANCE_ID = null;
    private static final Map<String, AtomicLong> COMPONENT_COUNTERS = new ConcurrentHashMap<>();
    private static final String DEFAULT_COMPONENT_NAME = "component";
    private static final Object lock = new Object();
    private static final Map<String, Meter> METER_CACHE = new HashMap<>();

    private TelicentMetrics() {
    }

    /**
     * Gets the configured Open Telemetry instance
     * <p>
     * This will either be the instance configured explicitly via {@link #set(OpenTelemetry)} or the global instance
     * from {@link GlobalOpenTelemetry#get()}.
     * </p>
     *
     * @return Open Telemetry instance
     */
    public static OpenTelemetry get() {
        synchronized (lock) {
            if (OTEL == null) {
                return GlobalOpenTelemetry.get();
            }
            return OTEL;
        }
    }

    /**
     * Sets a specific Open Telemetry instance, primarily intended for testing
     *
     * @param otel Open Telemetry instance
     */
    public static void set(OpenTelemetry otel) {
        synchronized (lock) {
            boolean needCacheReset = otel != OTEL;
            OTEL = otel;
            if (needCacheReset) {
                resetCaches();
            }
        }
    }

    /**
     * Resets to using the global Open Telemetry instance
     */
    public static void reset() {
        set(null);
    }

    /**
     * Gets the process-wide instance identifier used for metric attributes.
     * <p>
     * This resolves once per JVM, preferring explicit runtime configuration if present.
     * </p>
     *
     * @return Process-wide instance identifier
     */
    public static String getInstanceId() {
        synchronized (lock) {
            if (INSTANCE_ID == null) {
                INSTANCE_ID = resolveInstanceId();
            }
            return INSTANCE_ID;
        }
    }

    /**
     * Gets metric attributes that identify the current process instance.
     *
     * @return Attributes including the shared instance identifier
     */
    public static Attributes getInstanceAttributes() {
        return Attributes.of(AttributeKey.stringKey(AttributeNames.INSTANCE_ID), getInstanceId());
    }

    /**
     * Gets metric attributes for a specific item type on the current process instance.
     *
     * @param itemsType Item type label
     * @return Attributes including the shared instance identifier and item type
     */
    public static Attributes getMetricAttributes(String itemsType) {
        return Attributes.of(AttributeKey.stringKey(AttributeNames.ITEMS_TYPE), itemsType,
                             AttributeKey.stringKey(AttributeNames.INSTANCE_ID), getInstanceId());
    }

    /**
     * Gets metric attributes for a specific item type and metric producer on the current process instance.
     * <p>
     * The {@code componentId} distinguishes multiple producers of the same type within a single process instance and
     * should be obtained from {@link #nextComponentId(String)}. The {@link AttributeNames#INSTANCE_ID} remains shared across
     * all producers in the process so that all of a process's metrics can still be correlated.
     * </p>
     *
     * @param itemsType   Item type label
     * @param componentId Per-producer component identifier
     * @return Attributes including the shared instance identifier, item type, and component identifier
     */
    public static Attributes getMetricAttributes(String itemsType, String componentId) {
        return Attributes.of(AttributeKey.stringKey(AttributeNames.ITEMS_TYPE), itemsType,
                             AttributeKey.stringKey(AttributeNames.INSTANCE_ID), getInstanceId(),
                             AttributeKey.stringKey(AttributeNames.COMPONENT_ID), componentId);
    }

    /**
     * Mints a process-unique component identifier for a metric producer.
     * <p>
     * Combined with the shared {@link #getInstanceId()} this restores the ability to distinguish multiple metric
     * producers of the same type (e.g. several {@code ThroughputTracker} instances in one pipeline) without making the
     * process-wide instance identifier non-deterministic.
     * </p>
     * <p>
     * The {@code componentName} is embedded in the identifier so that a metric can be traced back to the code that
     * produced it, and an incrementing sequence is maintained <strong>per name</strong> so multiple producers of the
     * same kind read as {@code ThroughputTracker-0}, {@code ThroughputTracker-1}, etc. Uniqueness across process
     * restarts is provided by the instance identifier rather than the component identifier. Keep the name short and
     * bounded - do not derive it from per-event or otherwise unbounded data.
     * </p>
     *
     * @param componentName Human-readable name of the producing component, typically its class name; a blank name
     *                      falls back to {@value #DEFAULT_COMPONENT_NAME}
     * @return Process-unique component identifier of the form {@code <componentName>-<sequence>}
     */
    public static String nextComponentId(String componentName) {
        String name = componentName == null || componentName.isBlank() ? DEFAULT_COMPONENT_NAME : componentName;
        long sequence = COMPONENT_COUNTERS.computeIfAbsent(name, k -> new AtomicLong(0)).getAndIncrement();
        return name + "-" + sequence;
    }

    /**
     * Resets the cached process-wide instance identifier so it is re-resolved on next use.
     * <p>
     * Primarily intended for testing the resolution logic; not expected to be used in production code.
     * </p>
     */
    public static void resetInstanceId() {
        synchronized (lock) {
            INSTANCE_ID = null;
        }
    }

    private static void resetCaches() {
        METER_CACHE.clear();
    }

    private static String resolveInstanceId() {
        String resolved = Configurator.get(
                new String[] { OTEL_INSTANCE_ID_PROPERTY, INSTANCE_ID_ENV, SHARED_INSTANCE_ID_PROPERTY, HOSTNAME_ENV },
                UUID.randomUUID().toString());
        System.setProperty(SHARED_INSTANCE_ID_PROPERTY, resolved);
        return resolved;
    }

    /**
     * Gets or create the Meter instance for the given library
     * <p>
     * Library version detection will be attempted by calling {@link LibraryVersion#get(String)}, see
     * {@link LibraryVersion} for more details.
     * </p>
     *
     * @param library Library
     * @return Meter instance
     */
    public static Meter getMeter(String library) {
        return getMeter(library, LibraryVersion.get(library));
    }

    /**
     * Gets or creates the Meter instance for the given library
     *
     * @param library Library name
     * @param version Library version
     * @return Meter instance
     */
    public static Meter getMeter(String library, String version) {
        synchronized (lock) {
            return METER_CACHE.computeIfAbsent(String.format("%s-%s", library, version),
                                                  k -> get().meterBuilder(library)
                                                            .setInstrumentationVersion(version)
                                                            .build());
        }
    }

    private static final double NANOSECONDS_PER_SECOND = TimeUnit.SECONDS.toNanos(1);

    /**
     * Times a task (in seconds) recording its timing
     *
     * @param histogram        Histogram
     * @param metricAttributes Metric attributes
     * @param task             Task to run
     */
    public static void time(DoubleHistogram histogram, Attributes metricAttributes, Runnable task) {
        long start = System.nanoTime();
        try {
            task.run();
        } finally {
            long elapsed = System.nanoTime() - start;
            histogram.record(elapsed / NANOSECONDS_PER_SECOND, metricAttributes);
        }
    }

    /**
     * Times a task (in seconds) recording its timing
     *
     * @param histogram        Histogram
     * @param metricAttributes Metric attributes
     * @param task             Task to run
     * @param <T>              Task return type
     * @return Task return value
     * @throws Exception Thrown if there's a problem running the task
     */
    public static <T> T time(DoubleHistogram histogram, Attributes metricAttributes, Callable<T> task) throws
            Exception {
        long start = System.nanoTime();
        try {
            return task.call();
        } finally {
            long elapsed = System.nanoTime() - start;
            histogram.record(elapsed / NANOSECONDS_PER_SECOND, metricAttributes);
        }
    }
}
