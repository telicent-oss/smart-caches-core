/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.caches.configuration.auth.policy.examples;

import io.telicent.smart.caches.configuration.auth.annotations.RequirePermissions;
import jakarta.annotation.security.RolesAllowed;

@RolesAllowed({ "ADMIN"})
@RequirePermissions("admin:write")
// java:S1186 - empty methods are intentional stubs/no-op overrides in tests
@SuppressWarnings("java:S1186")
public class ExampleAdmin extends ExampleBase{

    public void doAdmin() {

    }

    @RolesAllowed({ "SYS-ADMIN"})
    @RequirePermissions({"admin:write", "admin:wipe" })
    public void reset() {

    }
}
