/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.cache.sources.file;

/**
 * Interface for file event reader/writers
 *
 * @param <TKey>   Key type
 * @param <TValue> Value type
 */
// java:S119 - TKey/TValue/TRequest generic naming convention is used across the codebase
@SuppressWarnings("java:S119")
public interface FileEventReaderWriter<TKey, TValue> extends FileEventReader<TKey, TValue>,
        FileEventWriter<TKey, TValue> {

    /**
     * Gets the mode this instance is operating in
     *
     * @return Mode
     */
    FileEventAccessMode getMode();
}
