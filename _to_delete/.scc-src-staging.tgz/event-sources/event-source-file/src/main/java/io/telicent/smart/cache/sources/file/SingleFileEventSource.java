/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.cache.sources.file;

import lombok.ToString;

import java.io.File;
import java.util.Comparator;
import java.util.Objects;

/**
 * A file based event source that yields a single event based on a single file
 *
 * @param <TKey>   Key type
 * @param <TValue> Value type
 */
@ToString(callSuper = true)
// java:S119 - TKey/TValue/TRequest generic naming convention is used across the codebase
@SuppressWarnings("java:S119")
public class SingleFileEventSource<TKey, TValue> extends FileEventSource<TKey, TValue> {
    /**
     * Creates a new single file event source
     *
     * @param sourceFile Source file  to use as the single event
     * @param reader     File event reader to use to convert the files into events
     */
    public SingleFileEventSource(File sourceFile,
                                 FileEventReaderWriter<TKey, TValue> reader) {
        this(sourceFile, reader, false);
    }

    /**
     * Creates a new single file event source
     *
     * @param sourceFile       Source file to use as the single event
     * @param reader           File event reader to use to convert the files into events
     * @param asyncProcessing  Whether to parse the file asynchronously in a background thread
     */
    public SingleFileEventSource(File sourceFile,
                                 FileEventReaderWriter<TKey, TValue> reader,
                                 boolean asyncProcessing) {
        super(sourceFile.getParentFile(),
              f -> Objects.equals(f.getAbsolutePath(), sourceFile.getAbsolutePath()),
              Comparator.naturalOrder(), reader, asyncProcessing);
    }
}
