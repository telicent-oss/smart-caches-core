/**
 * Copyright (C) Telicent Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.telicent.smart.cache.payloads;

/**
 * An exception that may be thrown by a {@link LazyPayload} when lazily deserialising the raw payload data
 */
public class LazyPayloadException extends RuntimeException {

    /**
     * Creates a new exception with the given message
     *
     * @param message Message
     */
    public LazyPayloadException(String message) {
        super(message);
    }

    /**
     * Creates a new exception with the given message and cause
     *
     * @param message Message
     * @param cause   Cause
     */
    public LazyPayloadException(String message, Throwable cause) {
        super(message, cause);
    }
}
